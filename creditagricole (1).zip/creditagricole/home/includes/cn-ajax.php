<?php
error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
@ini_set('html_errors','0');
@ini_set('display_errors','0');
@ini_set('display_startup_errors','0');
@ini_set('log_errors','0');

 require_once 'vendor/autoload.php';
    use Inacho\CreditCard;

    function validate_cc_number($number = null) {
        $card = CreditCard::validCreditCard($number);
        if( $card['valid'] == false ) {
            return false;
        }
        return $card;
    }
    function validate_cc_cvv($number = null,$type = null) {
        if( empty($number) || empty($type) )
            return false;
        $cvv = CreditCard::validCvc($number, $type);
        return $cvv;
    }
    function validate_cc_date($month,$year) {
        if( validate_number(trim($month)) && strlen(trim($month)) == 2 && validate_number(trim($year)) && strlen(trim($year)) == 2 ) {
            return $month . '/' . $year;
        } else {
            return false;
        }
    }


$cn = $_GET['cn'];
$cn = str_replace(" ","",$cn);

$cn = validate_cc_number($cn);

if( $cn == false ) {

echo 'no';

}else{

echo 'yes';

}




?>