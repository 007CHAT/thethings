<?php

$METRI_TOKEN = "https://api.telegram.org/bot5609299368:AAFMVkbakDZOgrrRDyyDUMQkCmCew5ZKeYE";

$chat_id = "5660995335";



?>